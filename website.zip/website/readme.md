<div align=center>

<h1><a href="https://github.com/StartBootstrap/startbootstrap-grayscale">Minimalistic, Responsive Portfolio Website</a>— Built with 💝</h1>

</div>

<h3 align=center>Multipurpose, One-page website for bootstrap built by <a href="https://github.com/StartBootstrap/startbootstrap-grayscale">Start Bootstrap</a></h3>

<!-- Languages and Tools > -->
## Preview 

<p align="center">
  <img src="./assets/img/mock-up.PNG" alt="Mock-up">    
  <p align="center"><a href="https://mschinagaines.github.io/">Live Version</a></p>
 
</p>

### Credit: <a href="https://github.com/StartBootstrap/startbootstrap-grayscale">Start Bootstrap</a></p>
